# telegramAdder
Its a python script that automatically fetch members from any telegram group and add them to your desired channel or group.


*********************THINGS TO KNOW**************************

1. You can only add 200 subscribers to telegram channel.
2. You can only add 50 members to telegram group with one account and the limit is 100k.
3. You can have as many telegram account as you want.
4. To add members to a group chat you need to first change the group to a SUPERGROUP before running the script.



*****************HOW TO USE TELEGRAM_ADDER*******************

1. Have python installed on your machine lol.
2. Go to https://my.telegram.org, login with your number to get your API_ID and API_HASH.
3. Run the python script on your terminal or cmd and follow the procedures :)... simple!!!



***************************  FAQ  ***************************

1. Can i run the script multiple times at once?

Answer : YES, you can... let say i have 4 accounts and i want to run all at once, i will copy and paste the scipts into 4 differents folders then open 4 terminals or cmd, and run those scripts. MAKE SURE not to run 1 account n two or more different terminals or cmd.


	DONT FORGET TO LEAVE A STAR


